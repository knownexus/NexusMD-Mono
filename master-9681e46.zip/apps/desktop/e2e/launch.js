import { _electron as electron } from '@playwright/test'
import { fileURLToPath } from 'node:url'
import { dirname, resolve, join } from 'node:path'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'

export const appDir = resolve(dirname(fileURLToPath(import.meta.url)), '..')

/**
 * Starts the real app in a way that works without a desktop session: a throwaway profile
 * (the shared one's cache folders can be locked, which makes Electron quit right after
 * "app ready") and no GPU. `seed` is a { storageKey: value } map written to localStorage
 * before the first render (a key starting with "profile:" goes under the active profile), so a test can start with repositories already registered.
 * `prefs` is written as the main process's prefs.json (e.g. { disabledApps: ['git'] }).
 * The window stays off screen unless `headed` (or HEADED=1) is set. Returns { app, win, close }; close() removes the profile.
 */
export async function launchApp({ seed = {}, prefs = null, args = [], headed = process.env.HEADED === '1' } = {}) {
  const userData = mkdtempSync(join(tmpdir(), 'nexusmd-e2e-'))
  if (prefs) writeFileSync(join(userData, 'prefs.json'), JSON.stringify(prefs))
  const app = await electron.launch({
    args: [appDir, `--user-data-dir=${userData}`, '--disable-gpu', ...args],
    env: { ...process.env, ...(headed ? {} : { NEXUSMD_HIDDEN: '1' }) },
  })
  const win = await app.firstWindow()
  await win.waitForLoadState('domcontentloaded')
  if (Object.keys(seed).length) {
    // The profile is created as the app boots; a split install loads its apps first, so wait for it
    // rather than seeding under a profile that does not exist yet.
    await win.waitForFunction(() => localStorage.getItem('nexusmd.activeProfileId'), null, { timeout: 30_000 })
    await win.evaluate(s => {
      const id = localStorage.getItem('nexusmd.activeProfileId')
      for (const [k, v] of Object.entries(s)) localStorage.setItem(k.startsWith('profile:') ? `nexusmd.p.${id}.${k.slice(8)}` : k, JSON.stringify(v))
    }, seed)
    await win.reload()
    await win.waitForLoadState('domcontentloaded')
  }
  return {
    app, win,
    async close() {
      await app.close().catch(() => {})
      rmSync(userData, { recursive: true, force: true })
    },
  }
}
