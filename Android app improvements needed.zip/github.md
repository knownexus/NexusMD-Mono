repo: knownexus/NexusMD-Mono
branch: master
path: apps/app

## Last sync
date: 2026-10-31T01:02:23Z

### Updated in this project
- Planner and Calendar, two options each (Turn 4)
- 3c Settings now covers every setting, incl. ADO, Jira, GitHub and SMTP forms
- Repo file browsing, confidential notes and Settings (Turn 3)
- Repos, Notes and Documents explored as 2 options each (Turn 2)
- Mobile Home, Work and Pull Requests explored as 2 options each
- Inline actions, undo, live sync status and offline queue added

## Screen map
| Screen | Repo files |
|---|---|
| Home (1a, 1b) | apps/app/src/views/view-dashboard.jsx, apps/app/src/data.jsx |
| Work (1c, 1d) | apps/app/src/views/view-workitems.jsx |
| Pull Requests (1e, 1f) | apps/app/src/views/view-prs.jsx, apps/app/src/components.jsx |
| Repos (2a, 2b) | apps/app/src/git-view.jsx, apps/app/src/git-browser.js |
| Notes (2c, 2d) | packages/ui/src/planner/planner-notes.jsx, apps/app/src/planner/planner-notes.jsx |
| Documents (2e, 2f) | apps/app/src/editor-screen.jsx, apps/app/src/adapters/editor-workspace.js |
| Repos with files (3a) | apps/app/src/git-view.jsx, apps/app/src/git-browser.js |
| Confidential notes (3b) | packages/ui/src/planner/planner-notes.jsx, apps/app/src/views/view-settings.jsx |
| Settings (3c, 3d) | apps/app/src/views/view-settings.jsx, apps/app/src/jira-settings.jsx, apps/app/src/work-screens.js, apps/app/src/app.jsx (SettingsModal) |
| Planner (4a, 4b) | apps/app/src/planner/view-planner.jsx, packages/core/src/modules/planner/index.js |
| Calendar (4c, 4d) | apps/app/src/views/view-calendar.jsx |
